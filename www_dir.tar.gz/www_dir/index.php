<?php
echo "<h1>TP MONTADO CORRECTAMENTE</h1>";
echo "<p>Servidor Apache usado /www_dir</p>";
?>
