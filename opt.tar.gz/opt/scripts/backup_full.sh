#!/bin/bash
#===========================
#Script: backup_full.sh
#===========================


#Función de ayuda

function ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo:"
    echo " $0 /var/logs /backup_dir"
    echo " $0 /www_dir /backup_dir"
    exit 1
}

#Validar cantidad de argumentos
if [ "$#" -ne 2 ]; then
     ayuda
fi
ORIGEN=$1
DESTINO=$2
NOMBRE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

#Validar origen
if [ ! -d "$ORIGEN" ]; then
    echo "ERROR: El directorio origen no existe."
    exit 2
fi

#Validar destino
if [ ! -d "$DESTINO" ]; then
    echo "ERROR: El directorio destino no existe."
    exit 3
fi

#Ejecutar backup
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

#Verificar resultado
if [ "$?" -eq 0 ]; then
    echo "Backup realizado correctamente: $DESTINO/$ARCHIVO"
else
    echo "ERROR al realizar backup"
    exit 4
fi
